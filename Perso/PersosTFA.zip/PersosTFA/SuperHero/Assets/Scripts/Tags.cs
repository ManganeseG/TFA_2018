﻿using UnityEngine;
using System.Collections;

public class Tags : MonoBehaviour 
{
	// Liste des tags
	public const string player = "Player";
	public const string gameController = "GameController";
}
