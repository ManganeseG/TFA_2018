﻿/* ----- Références -----
	basé sur ce tutoriel plus complet: 
	http://unity3d.com/learn/tutorials/projects/stealth/camera-movement
*/ 

using UnityEngine;
using System.Collections;

public class camera_move : MonoBehaviour 
{

// ----- Défintion des variables -----
	private Vector3 camera_dir;			// direction initiale de la camera
	private Transform characPlayer;		// référence au personnage qui est visé par la caméra
	private float camera_distance;		// distance entre la caméra et le characPlayer
	private float turn;					// joypad camera tourne autour du perso
	private float zoom;					// joypad camera zoom vers le perso


// ----- Initialisation -----
	void Awake ()
	{
		characPlayer = GameObject.FindGameObjectWithTag(Tags.player).transform;		// association du transfrom du personnage à la variable characPlayer

		Vector3 camera_pos_rel = transform.position - characPlayer.position;  		// calcul de la position relative de la camera par rapport au characPlayer
		camera_distance = camera_pos_rel.magnitude;									// calcul de la distance entre la caméra et le characPlayer
		camera_dir = camera_pos_rel.normalized;										// calcule la direction de la camera initiale en normalisant la position relative de la camera
	}

// ----- Boucle Principale -----
	void LateUpdate()
	{
		turn = Input.GetAxis ("Cam_turn") * 5f;	// mets a jour les valeurs des inputs
		zoom = Input.GetAxis ("Cam_zoom") + 1f;

		Camera_move ();		// déplacement de la camera
		Camera_orient();	// orientation de la camera
	}

// ----- Fonctions -----
	void Camera_move ()
	{
		camera_dir = Quaternion.AngleAxis(turn, Vector3.up) * camera_dir;	// calcul de la rotation du vecteur directeur normalisé (turnaround)
		Vector3 camera_pos_rel = camera_dir * camera_distance * zoom;		// calcul de la nouvelle distance entre le personnage et la camera (zoom)
		transform.position = characPlayer.position + camera_pos_rel; 		// calcul de la position finale de la camera par rapport au joueur
	}

	void Camera_orient ()
	{
		Vector3 aim_vector = characPlayer.position - transform.position + new Vector3 (0f, 1.0f, 0f);	// calcul du vecteur de direction de la caméra, avec un offset vertical
		transform.rotation = Quaternion.LookRotation(aim_vector, Vector3.up);							// calcul de l'orientation de la caméra par un lookat
	}
}